package tugas;
public class PersegiPanjang extends BangunDatar{
    private float panjang;
    private float lebar;
    void setPanjang(float panjang)
    {this.panjang = panjang;}
    void setLebar(float lebar)
    {this.lebar = lebar;}
    @Override void luas() {System.out.println(panjang * lebar);}
    @Override void keliling() {System.out.println(2 * (panjang + lebar));}
}
