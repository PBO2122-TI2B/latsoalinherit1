package tugas;
public abstract class BangunDatar {
    abstract void luas();
    abstract void keliling();
}
