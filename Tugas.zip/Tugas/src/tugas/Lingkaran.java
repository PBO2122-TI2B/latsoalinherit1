package tugas;
public class Lingkaran extends BangunDatar{
    private float r;
    void setR(float r){this.r = r;}
    @Override void luas(){System.out.println(r * r * 3.14);}
    @Override void keliling(){System.out.println(2 * r * 3.14);}
}
