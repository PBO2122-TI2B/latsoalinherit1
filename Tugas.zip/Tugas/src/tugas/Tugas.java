package tugas;
public class Tugas {
    public static void main(String[] args) {
        System.out.println("\nPersegi");
            PersegiPanjang a = new PersegiPanjang();
            a.setLebar(15);
            a.setPanjang(28);
            showLuasKeliling(a);
            System.out.println("\nsegitiga siku");
            Segitiga b = new Segitiga();
            b.setAlas(5);
            b.setTinggi(5);
            showLuasKeliling(b);
            System.out.println("\nlingkaran");
            Lingkaran c = new Lingkaran();
            c.setR(20);
            showLuasKeliling(c);
    }
    static void showLuasKeliling(BangunDatar a){
        System.out.print("luas = ");
        a.luas();
        System.out.print("keliling = ");
        a.keliling();
    }
}
