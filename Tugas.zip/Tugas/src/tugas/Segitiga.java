package tugas;
public class Segitiga extends BangunDatar{
    private float alas;
    private float tinggi;
    void setAlas(float alas){this.alas = alas;}
    void setTinggi(float tinggi){this.tinggi = tinggi;}
    float getAlas(){return this.alas;}
    float getTinggi(){return this.tinggi;}
    @Override void luas(){System.out.println((alas * tinggi) / 2);}
    @Override void keliling(){System.out.println( Math.sqrt( Math.pow(getAlas(), 2) 
            + Math.pow(getTinggi(), 2) ) );}
}
