package Inheritance;

public class BangunDatar {

    public float Luas(){
        System.out.print("Luas Bangun Datar : ");
        return 0;
    }
    public float Keliling(){
        System.out.print("\nKeliling Bangun Datar : ");
        return 0;
    }
}
