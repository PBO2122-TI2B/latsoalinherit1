/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jti.polinema.inheritance;
/**
 * Nama      : Rofika Nur 'Aini
 * NIM       : 2041720099
 * No. Absen : 24
 * Kelas     : 2B
 **/
public class Main {
    public static void main(String [] args){

        // instansiasi objek Persegi Panjang dan menginputkan value pada attribute-nya
        PersegiPanjang pp = new PersegiPanjang();
        pp.panjang = 17;
        pp.lebar = 3;
        
        // instansiasi objek Lingkaran dan menginputkan value pada attribute-nya
        Lingkaran l = new Lingkaran();
        l.r = 10;
        
        // instansiasi objek Segitiga dan menginputkan value pada attribute-nya
        Segitiga s = new Segitiga();
        s.alas = 7;
        s.tinggi = 24;
        
        // mengakses method luas dan keliling
        pp.luas();
        pp.keliling();
        
        l.luas();
        l.keliling();
        
        s.luas();
        s.keliling();
    }
}
