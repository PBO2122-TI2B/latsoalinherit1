/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jti.polinema.inheritance;
/**
 * Nama      : Rofika Nur 'Aini
 * NIM       : 2041720099
 * No. Absen : 24
 * Kelas     : 2B
 **/
public class BangunDatar {
    public float luas(){
        //System.out.println("Menghitung luas bangun datar");
        return 0;
    }
    public float keliling(){
        //System.out.println("Menghitung keliling bangun datar");
        return 0;
    }
}
