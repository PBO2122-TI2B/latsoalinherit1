public class BangunDatar {
    public float luas;
    public float keliling;
    
    public float luas(){
        System.out.println("Menghitung Luas Bangun Datar");
        return 0;
    }

    public float keliling(){
        System.out.println("Menghitung Keliling Bangun Datar");
        return 0;
    }
}

//Adika Ahmad Hanif Nazhir