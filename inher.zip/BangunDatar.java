package Inheritance;
public class BangunDatar {
    public float eLuas(){
        System.out.println("    Menghitung Luas");
        return 0;
    }
    public float eKeliling(){
        System.out.println("  Menghitung Keliling");
        return 0;
    }
}
