package bangundatar;

public class BangunDatar {
    public float hitungLuas(float luas) {
        return luas;
    }

    public float hitungKeliling(float keliling) {
        return keliling;
    }
}
